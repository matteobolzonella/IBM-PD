
userpath = "..."

forcings = farm_dataloader(userpath)
Param_vct = forcings[[2]]
output = farm_solver(forcings, Param_vct)


out_s1 = output[[1]]

Weight = out_s1[,2] 


dates_h = seq(from = strptime("23/08/2019 00:", format = "%d/%m/%Y %H:", tz = "UTC"),
              to = strptime("03/09/2019 23:", format = "%d/%m/%Y %H:" , tz = "UTC"),
              by = "hour")

date_leonardi = strptime(c("23/08/2019 00:", "03/09/2019 00:"), format = "%d/%m/%Y %H:" , tz = "UTC")
pesi_leonardi = c( 1350, 1530)

vaki_MA = read.csv(file = ".../MAweight.csv",
                   sep = ",", header = T)
vaki_MA$time = strptime(vaki_MA$time, format = "%d/%m/%Y", tz = "UTC")

Weight_dt = data.frame(time = format(dates_h, format = "%d/%m/%Y %H:"),
                       W = Weight)
write.csv(x = Weight_dt, file = ".../Weight.csv",
          row.names = F)

Weight_dt = read.csv(file = ".../Weight.csv",
                     sep = ",", header = T)


Weight_dt$time = strptime(Weight_dt$time, format = "%d/%m/%Y %H:", tz = "UTC")
Weight = Weight_dt$W

plot(dates_h[1:265], c(rep(NA, 48), Weight[1:217]), type = "l", ylim = c(1300,1650))
lines(vaki_MA$time[54:62], vaki_MA$peso_medio[54:62], col = "red")
points(date_leonardi, pesi_leonardi, pch = 20, col = "darkgreen")

dates_lab = seq(from = strptime("23/08/2019", format = "%d/%m/%Y", tz = "UTC"),
                to = strptime("03/09/2019", format = "%d/%m/%Y", tz = "UTC"),
                by = (60*60*24*1))



Sys.setlocale("LC_TIME", "English")
par(mar = c(4,4,1,1)+0.3)
plot(dates_h[1:265], c(rep(NA, 48), Weight[1:217]), type = "l", ylim = c(1300,1650), ylab = "", xlab = "",
     xaxt = "n", yaxt = "n")
mtext("Weight [g]", side = 2, line = 3, cex = 1)
mtext("Time [h]", side = 1, line = 2.5, cex = 0.9)
axis.POSIXct(side = 1, at = dates_lab, format = "%d %b", cex.axis = 0.9)
#mtext("Weight [g]", side = 2, line = 3)
axis(side = 2, at = pretty(range(c(1300,1650))), line = 0, las = 2, cex.axis = 0.8)
points(date_leonardi, pesi_leonardi, pch = 20, col = "darkgreen")
lines(vaki_MA$time[54:62], vaki_MA$peso_medio[54:62], col = "red")
legend(dates_lab[1], 1240, bty = "n", legend = c("Model", "BD"), lty = c(1,1),
       col = c("black", "red"), xpd = T, cex = 0.9)
legend(dates_lab[3], 1240, bty = "n", legend = "Samples", pch = 20, col = "darkgreen",
       xpd = T, cex = 0.9)




Sys.setlocale("LC_TIME", "English")
par(mar = c(4,4,1,3)+0.3)
plot(Water_temperature_dt$V1[1273:1537], Water_temperature_dt$V2[1273:1537], col = "grey", type = "l",
     xlab = "", ylab = "", axes = F)
box()
mtext("Water temperaure [�C]", side = 4, line = 2)
axis(side = 4, at = pretty(range(Water_temperature_dt$V2[1273:1537])), las = 2, cex.axis = 0.8)
par(new = T)
plot(dates_h[1:265], c(rep(NA, 48), Weight[1:217]), type = "l", ylim = c(1300,1650), ylab = "", xlab = "",
     xaxt = "n", yaxt = "n")
mtext("Weight [g]", side = 2, line = 3, cex = 1)
mtext("Time [h]", side = 1, line = 2.5, cex = 0.9)
axis.POSIXct(side = 1, at = dates_lab, format = "%d %b", cex.axis = 0.9)
#mtext("Weight [g]", side = 2, line = 3)
axis(side = 2, at = pretty(range(c(1300,1650))), line = 0, las = 2, cex.axis = 0.8)
points(date_leonardi, pesi_leonardi, pch = 20, col = "darkgreen")
lines(vaki_MA$time[54:62], vaki_MA$peso_medio[54:62], col = "red")
legend(dates_lab[1], 1240, bty = "n", legend = c("Model", "BD"), lty = c(1,1),
       col = c("black", "red"), xpd = T, cex = 0.9)
legend(dates_lab[8], 1240, bty = "n", legend = c("Water temperature [�c]"), lty = c(1),
       col = c("grey"), xpd = T, cex = 0.9)
legend(dates_lab[3], 1240, bty = "n", legend = "Samples", pch = 20, col = "darkgreen",
       xpd = T, cex = 0.9)


Sys.setlocale("LC_TIME", "English")
par(mar = c(4,4,1,3)+0.3)
plot(time_d, c(NA,NA, feed_ration_day[3:12]), col = "grey", type = "l",
     xlab = "", ylab = "", axes = F)
box()
mtext("Feed ration [g]", side = 4, line = 2)
axis(side = 4, at = pretty(range(feed_ration_day)), las = 2, cex.axis = 0.8)
par(new = T)
plot(dates_h[1:265], c(rep(NA, 48), Weight[1:217]), type = "l", ylim = c(1300,1650), ylab = "", xlab = "",
     xaxt = "n", yaxt = "n")
mtext("Weight [g]", side = 2, line = 3, cex = 1)
mtext("Time [h]", side = 1, line = 2.5, cex = 0.9)
axis.POSIXct(side = 1, at = dates_lab, format = "%d %b", cex.axis = 0.9)
#mtext("Weight [g]", side = 2, line = 3)
axis(side = 2, at = pretty(range(c(1300,1650))), line = 0, las = 2, cex.axis = 0.8)
points(date_leonardi, pesi_leonardi, pch = 20, col = "darkgreen")
lines(vaki_MA$time[54:62], vaki_MA$peso_medio[54:62], col = "red")
legend(dates_lab[1], 1240, bty = "n", legend = c("Model", "BD"), lty = c(1,1),
       col = c("black", "red"), xpd = T, cex = 0.9)
legend(dates_lab[8], 1240, bty = "n", legend = c("Feed ration [g]"), lty = c(1),
       col = c("grey"), xpd = T, cex = 0.9)
legend(dates_lab[3], 1240, bty = "n", legend = "Samples", pch = 20, col = "darkgreen",
       xpd = T, cex = 0.9)



Sys.setlocale("LC_TIME", "English")
par(mar = c(4,4,1,3)+0.3)
plot(Water_temperature_dt$V1[1273:1537], c(rep(NA, 48), Water_temperature_dt$V2[1321:1537]), col = "grey", type = "l",
     xlab = "", ylab = "", axes = F)
box()
mtext("Water temperaure [�C]", side = 4, line = 2)
axis(side = 4, at = pretty(range(Water_temperature_dt$V2[1273:1537])), las = 2, cex.axis = 0.8)
par(new = T)
plot(dates_h[1:265], c(rep(NA, 48), Weight[1:217]), type = "l", ylim = c(1300,1650), ylab = "", xlab = "",
     xaxt = "n", yaxt = "n")
mtext("Weight [g]", side = 2, line = 3, cex = 1)
mtext("Time [h]", side = 1, line = 2.5, cex = 0.9)
axis.POSIXct(side = 1, at = dates_lab, format = "%d %b", cex.axis = 0.9)
#mtext("Weight [g]", side = 2, line = 3)
axis(side = 2, at = pretty(range(c(1300,1650))), line = 0, las = 2, cex.axis = 0.8)
points(date_leonardi, pesi_leonardi, pch = 20, col = "darkgreen")
lines(vaki_MA$time[54:62], vaki_MA$peso_medio[54:62], col = "red")
legend(dates_lab[1], 1240, bty = "n", legend = c("Model", "BD"), lty = c(1,1),
       col = c("black", "red"), xpd = T, cex = 0.9)
legend(dates_lab[8], 1240, bty = "n", legend = c("Water temperature [�c]"), lty = c(1),
       col = c("grey"), xpd = T, cex = 0.9)
legend(dates_lab[3], 1240, bty = "n", legend = "Samples", pch = 20, col = "darkgreen",
       xpd = T, cex = 0.9)


Sys.setlocale("LC_TIME", "English")
par(mar = c(4,4,1,3)+0.3)
plot(time_d, c(NA,NA, feed_ration_day[3:12]), col = "grey", type = "l",
     xlab = "", ylab = "", axes = F)
box()
mtext("Feed ration [g]", side = 4, line = 2)
axis(side = 4, at = pretty(range(feed_ration_day)), las = 2, cex.axis = 0.8)
par(new = T)
plot(dates_h[1:265], c(rep(NA, 48), Weight[1:217]), type = "l", ylim = c(1300,1650), ylab = "", xlab = "",
     xaxt = "n", yaxt = "n")
mtext("Weight [g]", side = 2, line = 3, cex = 1)
mtext("Time [h]", side = 1, line = 2.5, cex = 0.9)
axis.POSIXct(side = 1, at = dates_lab, format = "%d %b", cex.axis = 0.9)
#mtext("Weight [g]", side = 2, line = 3)
axis(side = 2, at = pretty(range(c(1300,1650))), line = 0, las = 2, cex.axis = 0.8)
points(date_leonardi, pesi_leonardi, pch = 20, col = "darkgreen")
lines(vaki_MA$time[54:62], vaki_MA$peso_medio[54:62], col = "red")
legend(dates_lab[1], 1240, bty = "n", legend = c("Model", "BD"), lty = c(1,1),
       col = c("black", "red"), xpd = T, cex = 0.9)
legend(dates_lab[8], 1240, bty = "n", legend = c("Feed ration [g]"), lty = c(1),
       col = c("grey"), xpd = T, cex = 0.9)
legend(dates_lab[3], 1240, bty = "n", legend = "Samples", pch = 20, col = "darkgreen",
       xpd = T, cex = 0.9)




date_prendere = vaki_MA$time[54:62]


i = 1

pesi_simulati = rep(NA, length(date_prendere))

for (i in 1:length(date_prendere)) {
  
  pesi_simulati[i] = Weight_dt$W[format(Weight_dt$time, format = "%d/%m/%Y %H:") == format(date_prendere[i], format = "%d/%m/%Y %H:")]
  
}


plot(pesi_simulati, vaki_MA$peso_medio[54:62], pch = 20, xlim = c(1300,1650), ylim = c(1300,1650),
     xlab = "Predicted mean weight [g]", ylab = "Mean weight by BD [g]")
abline(a = 0, b = 1, lty = 2)
abline(a = 972.9943, b = 0.3543, col ="red")





aumento_peso_osservato = vaki_MA$peso_medio[54:62]-pesi_simulati[1]
aumento_peso_simulato = pesi_simulati-pesi_simulati[1]

summary(lm(aumento_peso_osservato~aumento_peso_simulato))


#summary(lm(pesi_simulati ~ vaki_MA$peso_medio[54:62]))


plot(pesi_simulati - pesi_simulati[1], vaki_MA$peso_medio[54:62] - pesi_simulati[1], pch = 20, xlim = c(0,200), ylim = c(0,200),
     xlab = "Predicted mean weight [g]", ylab = "Mean weight by BD [g]")
abline(a = 0, b = 1, lty = 2)
abline(a = 972.9943, b = 0.3543, col ="red")


sqrt(mean((vaki_MA$peso_medio[54:62]-pesi_simulati)^2))/max(pesi_simulati)
sum((vaki_MA$peso_medio[54:62]-pesi_simulati)^2)
sd(vaki_MA$peso_medio[54:62]-pesi_simulati)

library(plotrix)
par(mar = c(5,4,1,1))

taylor.diagram(vaki_MA$peso_medio[54:62], pesi_simulati, pos.cor= F, col = "blue", pch = 20,
               mar = c(5,1,5,1))


taylor.diagram(c(0,vaki_MA$peso_medio[54:62]), c(0,pesi_simulati), pos.cor= F, col = "blue", pch = 20,
               mar = c(5,1,5,1))


cor(y = vaki_MA$peso_medio[54:62],x =  pesi_simulati)

Leonardi_gestionale = read.csv(file = "",
                               sep = ";", header = T)

Leonardi_gestionale_limitato = Leonardi_gestionale[67:75, c(1,4)]
Leonardi_gestionale_limitato$Data = strptime(Leonardi_gestionale_limitato$Data, format = "%d/%m/%Y", tz = "UTC")

length(Leonardi_gestionale_limitato$Data)

biomassa = (Leonardi_gestionale_limitato$Numero.pesci* pesi_simulati)/(10^6)

Sys.setlocale("LC_TIME", "English")
par(mar = c(4,4,1,5))
plot(time_d, c(NA, NA, Leonardi_gestionale_limitato$Numero.pesci, NA), type = "l",
     xaxt = "n", axes = F, xlab = "", ylab = "", col = "grey")
box()
axis.POSIXct(side = 1, at = dates_lab, format = "%d %b", cex.axis = 0.9)
axis(side = 4, at = pretty(range(Leonardi_gestionale_limitato$Numero.pesci)), las = 2, cex.axis = 0.9)
mtext("Number of individuals", side = 4, line = 3.5, cex = 0.9)
par(new = T)
plot(time_d, c(NA, NA, biomassa, NA), type = "l", xlab = "", xaxt = "n", ylab = "", yaxt = "n")
axis(side = 2, at = pretty(range(biomassa)), las = 2, cex.axis = 0.9)
mtext("Total Biomass [ton]", side = 2, line = 3, cex = 0.9)
mtext("Time [d]", side = 1, line = 2.5, cex = 0.9 )
legend(dates_lab[1], 16.35, legend = c("Total biomass", "Number of indiviuals"), xpd = T, bty = "n",
       lty = c(1,1), col = c("grey", "black"), cex = 0.9)









ODE_numerosit� = function(t, NUM, par){
  with(as.list(c(par)),{
    
    m = par
    #cat("m", m, "\n")
    dNUM = -m*NUM
    
    list(dNUM)
  })
}

library(deSolve)
NUM_ini = 5000
par = (0.002715437/(24))
# divido per 24 perch� il tasso di mortalit� � su base giornaliera

times = 1:(length(Pesi_mtx[,1])+1)


nume_temp = rep(NA, length(Pesi_mtx[,1])+1)

nume_temp[1] = NUM_ini
# 
# for( i in 585:length(Pesi_mtx[,1])){
#   
#   out_num = ode(y = nume_temp[i-1], times = 1:2, func = ODE_numerosit�, parms = par, method = "rk4")
#   #nume_temp[i] = out_num[1,2]
#   nume_temp[i] = round(out_num[2,2], digits = 0)
#   #NUM_ini = nume_temp[i+1]
#   
# }
# 
# tail(nume_temp)

out_num2 = ode(y = NUM_ini, times = times, func = ODE_numerosit�, parms = par, method = "rk4")
























