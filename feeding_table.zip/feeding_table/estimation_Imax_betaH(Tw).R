eps_prot = 23600            # [J/g_prot]
eps_carb = 17200            # [J/g_carb]
eps_lipi = 36200            # [J/g_lip]

Pcont_3 = 0.48
Pcont_4.5 = 0.46
Pcont_6 = 0.45

Lcont_3 = 0.24
Lcont_4.5 = 0.25
Lcont_6 = 0.26

Ccont_3 = 0.15
Ccont_4.5 = 0.155
Ccont_6 = 0.16


energy_3 = (eps_prot*Pcont_3)+(eps_carb*Ccont_3)+(eps_lipi*Lcont_3)
energy_4.5 = (eps_prot*Pcont_4.5)+(eps_carb*Ccont_4.5)+(eps_lipi*Lcont_4.5)
energy_6 = (eps_prot*Pcont_6)+(eps_carb*Ccont_6)+(eps_lipi*Lcont_6)


taglia_media = c(70, 150, 300, 500, 700, 900)



percentuali_mtx = matrix(NA, nrow = length(taglia_media), ncol = 9)
percentuali_mtx[1,] = c(0.54, 0.63, 0.8, 0.93, 1.19, 1.46, 1.56, 1.62, 1.54)
percentuali_mtx[2,] = c(0.47, 0.55, 0.7, 0.81, 1.04, 1.28, 1.37, 1.42, 1.35)
percentuali_mtx[3,] = c(0.41, 0.49, 0.61, 0.71, 0.91, 1.13, 1.2, 1.25, 1.19)
percentuali_mtx[4,] = c(0.36, 0.43, 0.54, 0.63, 0.80, 0.99, 1.06, 1.1, 1.05)
percentuali_mtx[5,] = c(0.32, 0.38, 0.48, 0.55, 0.71, 0.87, 0.93, 0.97, 0.92)
percentuali_mtx[6,] = c(0.28, 0.33, 0.42, 0.49, 0.62, 0.77, 0.82, 0.85, 0.81)


energia_mtx = percentuali_mtx
energia_mtx[1,] = percentuali_mtx[1,] * energy_3/100
energia_mtx[2,] = percentuali_mtx[2,] * energy_4.5/100
energia_mtx[3,] = percentuali_mtx[3,] * energy_4.5/100
energia_mtx[4,] = percentuali_mtx[4,] * energy_6/100
energia_mtx[5,] = percentuali_mtx[5,] * energy_6/100
energia_mtx[6,] = percentuali_mtx[6,] * energy_6/100


a_TW_mtx = energia_mtx
a_TW_mtx[1,] = energia_mtx[1,] / (taglia_media[1]^(-1/3))
a_TW_mtx[2,] = energia_mtx[2,] / (taglia_media[2]^(-1/3))
a_TW_mtx[3,] = energia_mtx[3,] / (taglia_media[3]^(-1/3))
a_TW_mtx[4,] = energia_mtx[4,] / (taglia_media[4]^(-1/3))
a_TW_mtx[5,] = energia_mtx[5,] / (taglia_media[5]^(-1/3))
a_TW_mtx[6,] = energia_mtx[6,] / (taglia_media[6]^(-1/3))



plot(c(2,4,6,8,10,12,14,16,18),a_TW_mtx[1,], pch = 20, ylim = c(300,2100), main = "Imax*H(Tw)", xlab = "Water temperature [ �C]", ylab = "Imax*H(Tw) [J_feed/(g_fish)^m]")
points(c(2,4,6,8,10,12,14,16,18),a_TW_mtx[2,], pch = 20, col = "red")
points(c(2,4,6,8,10,12,14,16,18),a_TW_mtx[3,], pch = 20, col = "blue")
points(c(2,4,6,8,10,12,14,16,18),a_TW_mtx[4,], pch = 20, col = "darkgreen")
points(c(2,4,6,8,10,12,14,16,18),a_TW_mtx[5,], pch = 20, , col = "purple")
points(c(2,4,6,8,10,12,14,16,18),a_TW_mtx[6,], pch = 20, col = "darkslategrey")
lines(c(2,4,6,8,10,12,14,16,18), ImaxHTw_stimato, col = "darkorange", lwd = 2)

legend(1,0, bty = "n", xpd = T, col = c("black", "red", "blue"), legend = c("w = 70g", "w = 150g", "w = 300g"), pch = c(20,20,20) )
legend(3.5,0, bty = "n", xpd = T, col = c("darkgreen", "purple", "darkslategrey"), legend = c("w = 500g", "w = 700g", "w = 900g"), pch = c(20,20,20) )
legend(15,0, bty = "n", xpd = T, col = c("darkorange"), legend = c("Model"), lty = c(1), lwd = c(2))

ImaxHT_table_medio = apply(X = a_TW_mtx, MARGIN = 2, FUN = mean)
legend(1,0, bty = "n", xpd = T, col = c("black", "red"), legend = c("Mean Table", "Model"), pch = c(20,26), lty = c(0,1),  )



plot(c(2,4,6,8,10,12,14,16,18),ImaxHT_table_medio, pch = 20, ylim = c(300,2100), main = "Imax*H(Tw)", xlab = "Water temperature [ �C]", ylab = "Imax*H(Tw) [J_feed/(g_fish)^m]")
lines(c(2,4,6,8,10,12,14,16,18), ImaxHTw_stimato, col = "red", lwd = 2)


sqrt(mean((ImaxHT_table_medio-ImaxHTw_stimato)^2))



Temperature = c(2,4,6,8,10,12,14,16,18)
Toa = 16
Tma = 25

H_T = (((Tma-Temperature)/(Tma-Toa))^(betac*(Tma-Toa)))*exp(betac*(Temperature-Toa))


calibrazione_funzione = function(x, Temperature, Ht_tabella){
  Toa = 16
  Tma = 25
  H_T = (((Tma-Temperature)/(Tma-Toa))^(x*(Tma-Toa)))*exp(x*(Temperature-Toa))
  # Toa = 16
  # Tma = 25
  # 
  RSS = sum((H_T - Ht_tabella)^2)
  return(RSS)
}

Opt = optimize(f = calibrazione_funzione, interval = c(0,1), Temperature = Temperature, Ht_tabella = H_Tw_mtx[1,])


calibrazione_funzione2 = function(par, Temperature, ImaxHt_tabella){
  Toa = 16
  Tma = 25
  betac = par[1]
  Imax = par[2]
  H_T = (((Tma-Temperature)/(Tma-Toa))^(betac*(Tma-Toa)))*exp(betac*(Temperature-Toa))
  # Toa = 16
  # Tma = 25
  # 
  RSS = sum(((Imax*H_T) - ImaxHt_tabella)^2)
  return(RSS)
}



optim(par = c(0.1, 100), f = calibrazione_funzione2, Temperature = Temperature, ImaxHt_tabella = a_TW_mtx[1,])


H_T = (((Tma-Temperature)/(Tma-Toa))^(0.2172*(Tma-Toa)))*exp(0.2172*(Temperature-Toa))
ImaxHTw_stimato = 1830.557 * H_T

plot(c(2,4,6,8,10,12,14,16,18),a_TW_mtx[1,], pch = 20, ylim = c(300,2100), main = "Imax*H(Tw)", xlab = "Water temperature [ �C]", ylab = "Imax*H(Tw) [J_feed/(g_fish)^m]")
points(c(2,4,6,8,10,12,14,16,18),a_TW_mtx[2,], pch = 20, col = "red")
points(c(2,4,6,8,10,12,14,16,18),a_TW_mtx[3,], pch = 20, col = "blue")
points(c(2,4,6,8,10,12,14,16,18),a_TW_mtx[4,], pch = 20, col = "darkgreen")
points(c(2,4,6,8,10,12,14,16,18),a_TW_mtx[5,], pch = 20, , col = "purple")
points(c(2,4,6,8,10,12,14,16,18),a_TW_mtx[6,], pch = 20, col = "darkslategrey")
lines(c(2,4,6,8,10,12,14,16,18), ImaxHTw_stimato )


legend(1,0, bty = "n", xpd = T, col = c("black", "red", "blue"), legend = c("w = 70g", "w = 150g", "w = 300g"), pch = c(20,20,20) )
legend(3.5,0, bty = "n", xpd = T, col = c("darkgreen", "purple", "darkslategrey"), legend = c("w = 500g", "w = 700g", "w = 900g"), pch = c(20,20,20) )



calibrazione_funzione2 = function(par, Temperature, ImaxHt_tabella){
  Toa = 16
  Tma = 25
  betac = par[1]
  Imax = par[2]
  H_T = (((Tma-Temperature)/(Tma-Toa))^(betac*(Tma-Toa)))*exp(betac*(Temperature-Toa))
  # Toa = 16
  # Tma = 25
  # 
  RSS = sum(((Imax*H_T) - ImaxHt_tabella)^2)
  return(RSS)
}

a_TW_mtx


Imax_ott = rep(NA, 6)
betac_ott = rep(NA, 6)
RSS = rep(NA, 6)

for (i in 1:6) {
  
  Opt = optim(par = c(0.1, 1000), f = calibrazione_funzione2, Temperature = Temperature, ImaxHt_tabella = a_TW_mtx[i,])
  betac_ott[i] = Opt$par[1] 
  Imax_ott[i] = Opt$par[2] 
  RSS[i] = Opt$value[1]
  
}

plot(taglia_media, betac_ott, pch = 20, xlab = "Fish Weight [g]", ylab = "beta", main = "Estimated optimized beta")
abline(h = mean(betac_ott), col = "red", lty = 2)

plot(taglia_media, Imax_ott, pch = 20, xlab = "Fish Weight [g]", ylab = "Imax [J/(g_fish^m)]", main = "Estimated optimized Imax")
abline(h = mean(Imax_ott), col = "red", lty = 2)





plot(RSS, pch = 20)
mean(betac_ott)
sd(betac_ott)

mean(Imax_ott)
sd(Imax_ott)

mean(Imax_ott)/ energy_3
mean(Imax_ott)/ energy_4.5
(mean(Imax_ott)/ energy_4.5)*(342.96^(2/3))*((((Tma-12)/(Tma-Toa))^(mean(betac_ott)*(Tma-Toa)))*exp(mean(betac_ott)*(12-Toa)))


hist(Imax_ott)
hist(betac_ott)






plot(c(2,4,6,8,10,12,14,16,18),a_TW_mtx[1,], pch = 20, ylim = c(300,2100), main = "Imax*H(Tw)", xlab = "Water temperature [ �C]", ylab = "Imax*H(Tw) [J_feed/(g_fish)^m]")
points(c(2,4,6,8,10,12,14,16,18),a_TW_mtx[2,], pch = 20, col = "red")
points(c(2,4,6,8,10,12,14,16,18),a_TW_mtx[3,], pch = 20, col = "blue")
points(c(2,4,6,8,10,12,14,16,18),a_TW_mtx[4,], pch = 20, col = "darkgreen")
points(c(2,4,6,8,10,12,14,16,18),a_TW_mtx[5,], pch = 20, , col = "purple")
points(c(2,4,6,8,10,12,14,16,18),a_TW_mtx[6,], pch = 20, col = "darkslategrey")
lines(c(2,4,6,8,10,12,14,16,18), ImaxHTw_stimato )


legend(1,0, bty = "n", xpd = T, col = c("black", "red", "blue"), legend = c("w = 70g", "w = 150g", "w = 300g"), pch = c(20,20,20) )
legend(3.5,0, bty = "n", xpd = T, col = c("darkgreen", "purple", "darkslategrey"), legend = c("w = 500g", "w = 700g", "w = 900g"), pch = c(20,20,20) )


ImaxHTw_stimato3 = (1830.557+180.1196) * H_T
ImaxHTw_stimato2 = (1830.557-180.1196) * H_T



par(mar = c(4,4,1,1))

plot(c(2,4,6,8,10,12,14,16,18), ImaxHTw_stimato, type = "l", xaxt = "n",
     xlab = "", ylab = "", ylim = c(0,2100), yaxt = "n")
points(c(2,4,6,8,10,12,14,16,18),a_TW_mtx[1,], pch = 20, col = "chocolate2")
points(c(2,4,6,8,10,12,14,16,18),a_TW_mtx[2,], pch = 20, col = "red")
points(c(2,4,6,8,10,12,14,16,18),a_TW_mtx[3,], pch = 20, col = "blue")
points(c(2,4,6,8,10,12,14,16,18),a_TW_mtx[4,], pch = 20, col = "darkgreen")
points(c(2,4,6,8,10,12,14,16,18),a_TW_mtx[5,], pch = 20, , col = "purple")
points(c(2,4,6,8,10,12,14,16,18),a_TW_mtx[6,], pch = 20, col = "darkslategrey")
axis(side = 2, at = seq(0,2100,by = 250), las = 2, cex.axis = 0.9)
axis(side = 1, at = c(2,4,6,8,10,12,14,16,18), cex.axis = 0.9)
mtext("Water temperature [�C]", side = 1, line = 2.5, cex = 0.9)
mtext("Iopt [J/((gfish^m)*d)]", side = 2, line = 3, cex = 0.9)

legend(0,-275, bty = "n", xpd = T, col = c("chocolate2", "red"), legend = c("w = 70g", "w = 150g"), pch = c(20,20), cex = 0.9)
legend(2.5,-275, bty = "n", xpd = T, col = c("blue","darkgreen"), legend = c( "w = 300g", "w = 500g"), pch = c(20,20), cex = 0.9)
legend(5,-275, bty = "n", xpd = T, col = c("purple", "darkslategrey"), legend = c("w = 700g", "w = 900g"), pch = c(20,20), cex = 0.9)
legend(14,-300,legend = "Model" , bty = "n", xpd = T, col = "black", lty = 1, , cex = 0.9)




par(mar = c(4,4,1,1))

plot(c(2,4,6,8,10,12,14,16,18), ImaxHTw_stimato, type = "l", xaxt = "n",
     xlab = "", ylab = "", ylim = c(0,2100), yaxt = "n")
lines(c(2,4,6,8,10,12,14,16,18), ImaxHTw_stimato2, lty = 2)
lines(c(2,4,6,8,10,12,14,16,18), ImaxHTw_stimato3, lty = 2)
points(c(2,4,6,8,10,12,14,16,18),a_TW_mtx[1,], pch = 20, col = "chocolate2")
points(c(2,4,6,8,10,12,14,16,18),a_TW_mtx[2,], pch = 20, col = "red")
points(c(2,4,6,8,10,12,14,16,18),a_TW_mtx[3,], pch = 20, col = "blue")
points(c(2,4,6,8,10,12,14,16,18),a_TW_mtx[4,], pch = 20, col = "darkgreen")
points(c(2,4,6,8,10,12,14,16,18),a_TW_mtx[5,], pch = 20, , col = "purple")
points(c(2,4,6,8,10,12,14,16,18),a_TW_mtx[6,], pch = 20, col = "darkslategrey")
axis(side = 2, at = seq(0,2100,by = 250), las = 2, cex.axis = 0.9)
axis(side = 1, at = c(2,4,6,8,10,12,14,16,18), cex.axis = 0.9)
mtext("Water temperature [�C]", side = 1, line = 2.5, cex = 0.9)
mtext("Iopt [J/((gfish^m)*d)]", side = 2, line = 3, cex = 0.9)

legend(0,-275, bty = "n", xpd = T, col = c("chocolate2", "red"), legend = c("40g - 100g", "100g - 200g"), pch = c(20,20), cex = 0.9)
legend(2.5,-275, bty = "n", xpd = T, col = c("blue","darkgreen"), legend = c( "200g - 400g", "400g - 600g"), pch = c(20,20), cex = 0.9)
legend(5,-275, bty = "n", xpd = T, col = c("purple", "darkslategrey"), legend = c("600g - 800g", "800g - 1000g"), pch = c(20,20), cex = 0.9)
legend(14,-300,legend = "Model mean" , bty = "n", xpd = T, col = "black", lty = 1, , cex = 0.9)
legend(14,-400,legend = "Model SD" , bty = "n", xpd = T, col = "black", lty = 2, , cex = 0.9)






