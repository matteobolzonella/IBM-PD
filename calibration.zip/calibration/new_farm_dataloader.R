#' Questo sottoprogramma serve per leggere i files delle forzanti
#' e produrre le funzioni approssimanti
#'
#'

farm_dataloader = function(userpath){
  
  # print("Inside dataloader")
  # print(environment())
  
  # Reads Water temperature, Feed ration, DO input, number of fish, liquid oxygen added by farmer files
  Ttem = read.csv(file = paste0(userpath,"/Water_temperature.csv"), sep = ",", header=F)                      # Reading the temperature time series (hourly series) data
  DaF = read.csv(file = paste0(userpath,"/feed.csv") ,sep = ",", header = F)                                  # Reading the individual feeding dose time series (hourly series) data
  DO_input = read.csv(file = paste0(userpath,"/DO_in.csv"), sep = ",", header = F)                            # Reading the DO input time series (hourly series)
  Coorte_num = read.csv(file = paste0(userpath,"/num_individuals.csv"), sep = ",", header = F)                # Reading the number of fish time series (hourly series)
  Aggiunta_O = read.csv(file = paste0(userpath,"/liq_oxy.csv"), sep = ",", header = F)                        # Reading the O2 added time series 
  Amm_input = read.csv(file = paste0(userpath,"/Amm_in.csv"), sep = ",", header = F )                         # Reading the NH4 input
  pH_input = read.csv(file = paste0(userpath,"/pH_entry.csv"), sep = ",", header = F )                        # Reading the pH input
  pH_out = read.csv(file = paste0(userpath,"/pH_out.csv"), sep = ",", header = F )                            # Reading the pH input
  
  
  # Reads feed composition file
  Food_matrix = read.csv(file = paste0(userpath,"/Food_characterization.csv"), sep = ",", header = F)   # Reading the food composition (Proteins, Lipids, Carbohydrates) data
  Food=as.double(as.matrix(Food_matrix[,1]))                                                            # Trasformazione dei valori della matrice della caratterizzazione del cibo in vettore di numeri reali
  
  # Reads integration extremes
  Param_matrix = read.csv(file = paste0(userpath,"/Parameters.csv"), sep=",", header = T)        # Reading the matrix containing parameters and their description
  Param=as.double(as.matrix(Param_matrix[1:31,3]))                                               # conversione dei valori dei parametri della matrici in vettore di numeri reali
  
  # Creazione dei vettori contenenti il tempo di osservazione ed i dati osservati dai file delle forzanti
  # time[I] � un vettore di tipo character contentente date ed orari nel formato "%d/%m/%Y %H:"
  # [I] � un vettore di numeri
  
  # temperatura dell'acqua oraria
  timeT = as.matrix(Ttem[,1])                                 # Vector of the times of Temperature measurements
  Temperature = as.double(as.matrix(Ttem[,2]))                # Vector of water temperature time series (hourly series)
  
  # razione alimentare oraria
  timeG = as.matrix(DaF[,1])                                  # Vector of the times of feeding dose
  G = as.double(as.matrix(DaF[,2]))                           # Vector of the individual feeding dose time series (hourly series)
  
  # DO in entrata
  timeDO_input = as.matrix(DO_input[,1])                      # vector of times for which DO input is available
  DO_in = as.double(as.matrix(DO_input[,2]))                  # vector of DO input time series (hourly series)
  
  # numero di indivui presenti in vasca
  timeCoorte = as.matrix(Coorte_num[,1])                      # vector of times for which number of reared fish is available
  coorte_num_fish = as.double(as.matrix(Coorte_num[,2]))      # vector of number of fish time series is available (hourly series)
  
  # ossigeno liquido aggiunto dall'allevatore
  timeO2 = as.matrix(Aggiunta_O[,1])                          # vector of times for which liquid O2 provision time series is available
  O2_add = as.double(as.matrix(Aggiunta_O[,2]))               # vector of liquid Oxygen added time series (hourly series)
  
  # NH4 in entrata
  timeNH4_input = as.matrix(Amm_input[,1])                    # vector of times for which NH4 input time series is available
  NH4_input = as.double(as.matrix(Amm_input[,2]))             # vector of NH4 input time series (hourly series)
  
  # pH in entrata
  timepH_input = as.matrix(pH_input[,1])                      # vector of times for which pH time series measured at the entry is available
  pH_values_input = as.double(as.matrix(pH_input[,2]))        # vector time series of pH measured at the inlet (hourly series)
  
  # pH in uscita
  timepH_out = as.matrix(pH_out[,1])                          # vector of times for which pH times series measured at the outlet is available
  pH_outlet = as.double(as.matrix(pH_out[,2]))                # vector time series of pH measured at the outlet (hourly series)
  
  # Estrazione del tempo di inizio e fine simulazione
  Dates = Param_matrix[32:33,3]                               # Vector containing the starting and ending date of the simulation
  # Dates � un vettore di variabile categoriale con i 2 tempi. Gli altri valori della tabella dei parametri vengono messi con Livelli in ordine crescente
  
  # Definizione dei tempi di simulazione
  # Times needed to perform interpolation
  t0 = min(as.numeric(strptime(timeT[1], format = "%d/%m/%Y %H:")), as.numeric(strptime(timeG[1], format = "%d/%m/%Y %H:")),
           as.numeric(strptime(timeDO_input[1], format = "%d/%m/%Y %H:")), as.numeric(strptime(timeCoorte[1], format = "%d/%m/%Y %H:")),
           as.numeric(strptime(timeO2[1], format = "%d/%m/%Y %H:")), as.numeric(strptime(timeNH4_input[1], format = "%d/%m/%Y %H:")),
           as.numeric(strptime(timepH_input[1], format = "%d/%m/%Y %H:")), as.numeric(strptime(timepH_out[1], format = "%d/%m/%Y %H:")))
  
  ti = ((as.numeric(strptime(Dates[1], "%d/%m/%Y %H:"))-t0)/3600)+1           # Start of integration [day with hour]
  tf = ((as.numeric(strptime(Dates[2], "%d/%m/%Y %H:"))-t0)/3600)+1           # End of integration [day with hour]
  # Utilizzando striptime and as.numeric ti e tf vengono convertiti in un certo numero che dista da t0 il numero di secondi da t0. 
  # Per ottenere le ore quindi divido per 3600 e poi aggiungo 1 per posizionarmi correttamente nel vettore. A questo punto posso definire il passo come 1 ora
  
  timestep = 1
  
  index_time = c(t0, ti, tf, timestep)                        # vettore contenente le informazioni relative al tempo di simulazione. Serve quando il codice viene diviso in sootofunzioni
  
  
  # Ora creo il vettore che stima l'ingestione reale da parte degli individui considerando che viene mangiata tutta la razione alimentare fornita ad eccezione che la temperatura dell'acqua sia sotto alla temperatura di alimentazione minima
  
  # Recupero del valore di temperatura minima di alimentazione dalla tabella dei parametri
  Taa = Param[17]          # [Celsius degree] Lowest feeding temperature for Oncorhynchus mykiss
  
  
  # Inizializzazione del vettore di ingestione reale. 
  ingvero = rep(0, length(ti:tf))
  
  # Setting ingestion according to  lowest feeding temperature 
  # Lowest feeding temperature threshold
  for( j in (ti:tf)-ti){
    if (Temperature[j + ti]<Taa) {
      ingvero[j+1] = 0
    } else {
      ingvero[j+1] = G[j+ti] 
    }
  }
  
  # Creazione dei dataframe per ciascuno delle forzanti utilizzate e delle funzioni forzanti:
  
  # Ingestione reale
  ingvero.df = data.frame(time = ti:tf, ingvero = ingvero)
  ingvero_app <<- approxfun(ingvero.df, rule = 2)
  
  # Temperatura dell'acqua
  Temperature_df = data.frame(time = ti:tf, Temperature = Temperature[ti:tf])
  Temperature_app <<- approxfun(Temperature_df, rule = 2)
  Temperature_df = cbind(Temperature_df, dates = timeT[ti:tf])
  
  # Razione alimentare fornita dall'allevatore
  G.df = data.frame(time = ti:tf, G = G[ti:tf])
  G_app <<- approxfun(G.df, rule = 2)
  
  # DO in entrata
  DO_input_df = data.frame(time = ti:tf, DO_input = DO_in[ti:tf])
  DO_input_app <<- approxfun(DO_input_df, rule = 2)
  
  # Ossigeno liquido fornito dall'allavatore e creazione della funzione approssimante
  liquid_O2_df = data.frame(time = ti:tf, liq_O2 = O2_add[ti:tf])
  liq_O2_app <<- approxfun(liquid_O2_df, rule = 2)
  
  # Numero di individui presenti in vasca e creazione della funzione approssimante
  pop_num_fish = data.frame(time = ti:tf, num_fish = coorte_num_fish[ti:tf])
  pop_num_app <<- approxfun(pop_num_fish, rule = 2)
  
  # NH4 input e creazione della funzione approssimante
  NH4_input_df = data.frame(time = ti:tf, NH4_input = NH4_input[ti:tf])
  NH4_input_app <<- approxfun(NH4_input_df, rule = 2)
  
  
  # Initial conditions
  # W = as.double(as.matrix(Param_matrix[30,3]))                   # [g] weight initial condition
  # DO = as.double(as.matrix(Param_matrix[31,3]))                  # [mg/L] DO initial condition
  # NH4 = as.double(as.matrix(Param_matrix[32,3]))                 # [mg/L] NH4 initial condition
  IC = c(W = as.double(as.matrix(Param_matrix[34,3])),
         DO = as.double(as.matrix(Param_matrix[35,3])))            # Initial conditions
  IC_NH4 = as.double(as.matrix(Param_matrix[36,3]))
  # Stima della CO2
  parameter_CO2 = Param[30:31]
  
  # stima co2 in entrata
  out_CO2_entrata = CO2_function(pH_values_input[ti:tf], Temperature[ti:tf], parameter_CO2)
  # CO2_entrata =  out_CO2_entrata[[1]]
  # HCO3_entrata = out_CO2_entrata[[2]]
  # CO3_entrata = out_CO2_entrata[[3]]
   
  # creazione del dataframe con tutti i risultati del modulo CO2 all'equilibrio in entrata
  CO2_entrata_df = data.frame(time = ti:tf, CO2_entry = out_CO2_entrata[[1]], HCO3_entry = out_CO2_entrata[[2]], CO3_entry = out_CO2_entrata[[3]])
  
  # stima della CO2 in uscita
  out_uscita = CO2_function(pH_outlet[ti:tf], Temperature[ti:tf], parameter_CO2)
  # CO2_uscita = out_uscita[[1]]
  # HCO3_uscita = out_uscita[[2]]
  # CO3_uscita = out_uscita[[3]]
  
  # creazione del dataframe con tutti i risultati del modulo CO2 in uscita
  CO2_uscita_df = data.frame(time = ti:tf, CO2_exit = out_uscita[[1]], HCO3_exit = out_uscita[[2]], CO3_exit = out_uscita[[3]])
  
  return(list(
    index_time, 
    Param,
    Food,
    Temperature_df,
    ingvero.df, 
    G.df, 
    DO_input_df, 
    liquid_O2_df,
    pop_num_fish,
    NH4_input_df,
    IC,
    IC_NH4,
    CO2_entrata_df,
    CO2_uscita_df
  ))
  
}
