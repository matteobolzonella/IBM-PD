

Vaki_ma = read.csv(file = ".../MAweight.csv", sep = ",", header = T)
# Vaki_ma$time = strptime(Vaki_ma$time, format = "%d/%m/%Y", tz = "UTC")
vaki_ma_new = Vaki_ma[c(4:115,117:125),]
vaki_ma_new$time = strptime(vaki_ma_new$time, format = "%d/%m/%Y", tz = "UTC")

vaki_sd = read.csv(file = ".../vaki_analysis.csv", sep = ",", header = T)
#vaki_sd$time = strptime(vaki_sd$time, format = "%Y-%m-%d", tz  = "UTC")
vaki_sd_new = vaki_sd[c(4:115,117:125),]
vaki_sd_new$time = strptime(vaki_sd_new$time, format = "%Y-%m-%d", tz  = "UTC")


dates = seq(from = strptime("06/07/2020", format = "%d/%m/%Y", tz = "UTC"),
            to = strptime("03/11/2020", format = "%d/%m/%Y", tz = "UTC" ),
            by = "day")

# n -> numero di serie sintetiche che si vuole creare
n = 100

Pesi_vaki_sintetici = matrix(NA, nrow = n, ncol = length(dates))

set.seed(1)

for (j in 1:length(dates)){
  
    if(!is.na(vaki_ma_new$weight_mean[j])){
      
      Pesi_vaki_sintetici[,j] = rnorm(n, mean = vaki_ma_new$weight_mean[j], sd = vaki_sd_new$sd_stimata[j])
    
    }
  else{
    
    Pesi_vaki_sintetici[,j] = rep(NA, length(n))
    
  }
}


View(Pesi_vaki_sintetici[1,])
prova = data.frame(time = dates, w = Pesi_vaki_sintetici[1,])
prova$time[!is.na(prova$w)]

for(i in 1:n){
  cat("i for", i, "\n")
  for (j in 1:length(dates)) {
    #cat("j for", j, "\n")
    if(!is.na(Pesi_vaki_sintetici[i,j])){
      if(Pesi_vaki_sintetici[i,j] < 0){
        cat(Pesi_vaki_sintetici[i,j], "\n")
        cat("i", i, "\n")
        cat("j",j, "\n")
      }
    } else{
      
    }
    
    
    
  }
  
}



Pesi_vaki_sintetici[5,3] = rnorm(1, mean = vaki_ma_new$weight_mean[3], sd = vaki_sd_new$sd_stimata[3])
Pesi_vaki_sintetici[32,3] = rnorm(1, mean = vaki_ma_new$weight_mean[3], sd = vaki_sd_new$sd_stimata[3])
Pesi_vaki_sintetici[57,3] = rnorm(1, mean = vaki_ma_new$weight_mean[3], sd = vaki_sd_new$sd_stimata[3])
Pesi_vaki_sintetici[55,19] = rnorm(1, mean = vaki_ma_new$weight_mean[19], sd = vaki_sd_new$sd_stimata[19])
Pesi_vaki_sintetici[11,19] = rnorm(1, mean = vaki_ma_new$weight_mean[19], sd = vaki_sd_new$sd_stimata[19])
Pesi_vaki_sintetici[26,19] =  rnorm(1, mean = vaki_ma_new$weight_mean[19], sd = vaki_sd_new$sd_stimata[19])
Pesi_vaki_sintetici[60,25] =  rnorm(1, mean = vaki_ma_new$weight_mean[25], sd = vaki_sd_new$sd_stimata[25])
Pesi_vaki_sintetici[64,19] =  rnorm(1, mean = vaki_ma_new$weight_mean[19], sd = vaki_sd_new$sd_stimata[19])
Pesi_vaki_sintetici[67,24] =  rnorm(1, mean = vaki_ma_new$weight_mean[24], sd = vaki_sd_new$sd_stimata[24])
Pesi_vaki_sintetici[77,3] = rnorm(1, mean = vaki_ma_new$weight_mean[3], sd = vaki_sd_new$sd_stimata[3])
Pesi_vaki_sintetici[99,19] =  rnorm(1, mean = vaki_ma_new$weight_mean[19], sd = vaki_sd_new$sd_stimata[19])


