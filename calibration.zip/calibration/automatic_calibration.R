userpath = "..."

dates = as.numeric(seq(from = strptime("06/07/2020 00:", format = "%d/%m/%Y %H:", tz = "UTC"),
 to = strptime("03/11/2020 23:", format = "%d/%m/%Y %H:" , tz = "UTC"),
 by = "day"))

dates_h = as.numeric(seq(from = strptime("06/07/2020 00:", format = "%d/%m/%Y %H:"),
 to = strptime("03/11/2020 23:", format = "%d/%m/%Y %H:" ),
 by = "hour"))

# PREVIOUSLY GENERATE THE MATRIX OF SIMULATED WEIGHT
# PREVIOUSLY LOAD DATA FROM BD (VAKI_MA AND VAKI_SD)

vaki_sd_nonNA = vaki_sd_new$sd_stimata[!is.na(vaki_sd_new$sd_stimata)]
#Pesi_vaki_sintetici[1, !is.na(Pesi_vaki_sintetici[1,])]

RSS_pes = function(par, weigth_observed, userpath, tempo, tempo_h, vaki_sd_nonNA){
  
  forcings = farm_dataloader(userpath)
  Param_vct = forcings[[2]]
  
  alfa = par[1]
  
  Param_vct[2] = alfa
  
  IC_list = forcings[[11]]
  ICW = par[2]
  IC_list[1] = (W = ICW)
  forcings[[11]] = IC_list
  
  
  output = farm_solver(forcings, Param_vct)
  out_s1 = output[[1]]
  
  
  # TO SOLVE ISSUE WITH NA
  Output_dt = data.frame(time = tempo_h,
                         W_pred = out_s1[,2])
  #Output_dt$time = strptime(Output_dt$time, format = "%d/%m/%Y %H:", tz = "UTC")
  
  Observed_dt = data.frame(time = tempo,
                           W_obs = weigth_observed)
  #Observed_dt$time = strptime(Observed_dt$time, format = "%d/%m/%Y", tz = "UTC")
  
  date_confronto = Observed_dt$time[!is.na(Observed_dt$W_obs)]
  
  pesi_confronto = rep(NA, length(date_confronto))
  
  # i = 1
  for (i in 1:length(date_confronto)) {
    
    pesi_confronto[i] = Output_dt$W_pred[Output_dt$time == date_confronto[i]]
    
  }
  
  
  RSS_pes = sum(((Observed_dt$W_obs[!is.na(Observed_dt$W_obs)] - pesi_confronto)^2)/vaki_sd_nonNA)
  
  return(RSS_pes)
}

Alfa = rep(NA, n)
W0_ott = rep(NA, n)
RSS_pes_fin = rep(NA, n)

for (i in 1:n){
Opt = optim(par = c(0.4, 309.45), fn = RSS_pes, weigth_observed = Pesi_vaki_sintetici[i,], userpath = userpath, tempo = dates, tempo_h = dates_h, vaki_sd_nonNA = vaki_sd_nonNA)


Alfa[i] = Opt$par[1]
W0_ott[i] = Opt$par[2]
RSS_pes_fin[i] = Opt$value[1]
}
# dates = as.numeric(dates)
# dates_h = as.numeric(dates_h)

Risultati_dt = data.frame(Alfa = Alfa, W0_ott = W0_ott, RSS_pes = RSS_pes_fin )
write.csv(x = Risultati_dt, file = ".../Risultati_calibrazione_100ts.csv", row.names = F)

mean(Alfa)
median(Alfa)
sd(Alfa)
IQR(Alfa)
mean(W0_ott)
sd(W0_ott)


hist(Alfa, main = "Distribution of optimized Alpha", xlab = "alpha", freq = F)
hist(W0_ott, main = "Distribution of optimized initial weigth", xlab = "Optimal Initial weight [g]", freq = F)
