

Weight_dt = read.csv(file = ".../Weight.csv",
                     sep = ",", header = T)

Weight_dt$time = strptime(Weight_dt$time, format = "%d/%m/%Y %H:", tz = "UTC")


vaki_MA = read.csv(file = ".../MAweight.csv",
                   sep = ",", header = T)
vaki_MA$time = strptime(vaki_MA$time, format = "%d/%m/%Y", tz = "UTC")


date_leonardi = strptime(c("07/09/2020 00:", "16/10/2020 00:", "02/11/2020 00:"), format = "%d/%m/%Y %H:" , tz = "UTC")
pesi_leonardi = c( 340, 475, 550)

Water_temperature_dt = read.csv(file = ".../Water_temperature.csv",
                                sep = ",", header = F)
Water_temperature_dt$V1 = strptime(Water_temperature_dt$V1, format = "%d/%m/%Y %H:", tz = "UTC")


Feed_dt = read.csv(file = ".../feed.csv",
                   sep = ",", header = F)
Feed_dt$V1 = strptime(Feed_dt$V1, format = "%d/%m/%Y %H:", tz = "UTC")


time_d = seq(from = strptime("06/07/2020", format = "%d/%m/%Y", tz = "UTC"),
             to = strptime("03/11/2020", format = "%d/%m/%Y", tz = "UTC"),
             by = "day")

time_h = seq(from = strptime("06/07/2020 00:", format = "%d/%m/%Y %H:"),
             to = strptime("03/11/2020 23:", format = "%d/%m/%Y %H:"),
             by = "hour")


dates_lab = seq(from = strptime("06/07/2020 00:", format = "%d/%m/%Y %H:"),
             to = strptime("03/11/2020 23:", format = "%d/%m/%Y %H:"),
             by = (60*60*24*15))

Leonardi_gestionale = read.csv(file = ".../riassunto_V4.csv",
                               sep = ";", header = T)

Leonardi_gestionale_lim = Leonardi_gestionale[405:525, c(4,9)]
(Leonardi_gestionale_lim$Q.t�..kg.*1000)/Leonardi_gestionale_lim$Num.



feed_day = rep(NA, length(time_d))


i = 1
for (i in 1:length(time_d)) {
  
  feed_day[i] = sum(Feed_dt$V2[format(Feed_dt$V1, format = "%d/%m/%Y") == format(time_d[i], format = "%d/%m/%Y")])
  
}






Sys.setlocale("LC_TIME","English")
par(mar = c(4,4,1,3))
plot(time_d, feed_day, type = "l", col = "grey", xaxt = "n", yaxt = "n", ylab = "", xlab = "")
mtext("Feed ration [g]", side = 4, cex = 0.9, line = 1.5)
axis(side = 4, at = pretty(range(feed_day)), las = 2, cex.axis = 0.9)
par(new = T)
plot(time_h, Weight_dt$W, type = "l", xlab = "", ylab = "", xaxt  ="n", yaxt = "n", ylim = c(min(vaki_MA$Weight_mean, na.rm = T), max(c(vaki_MA$Weight_mean, Weight_dt$W), na.rm = T)))
lines(vaki_MA$time[4:124], vaki_MA$Weight_mean[4:124], col = "red")
points(date_leonardi, pesi_leonardi, pch = 20, col = "darkgreen")

axis(side = 2, at = pretty(range(Weight_dt$W)), cex.axis = 0.9, las = 2)
mtext( "Weight [g]", side = 2, line = 3, cex = 0.9)
axis.POSIXct(side = 1, at = dates_lab, format = "%d %b",cex.axis = 0.9)
mtext("Time [h]", side = 1, line = 2.5, cex = 0.9)
legend(dates_lab[1], 200, legend = c("Model", "BD"), xpd = T, bty = "n", col = c("black", "red"), lty = c(1,1), cex = 0.9)
legend(dates_lab[3], 200, legend = "Samples", pch = 20, col = "darkgreen", xpd = T, bty = "n", cex = 0.9)
legend(dates_lab[7], 200, legend = "Feed ration", lty = 1, col = "grey", xpd = T, bty = "n", cex = 0.9)




Sys.setlocale("LC_TIME","English")
par(mar = c(4,4,1,3))
plot(Water_temperature_dt$V1[121:3024], Water_temperature_dt$V2[121:3024], type = "l", col = "grey", xaxt = "n", yaxt = "n", ylab = "", xlab = "")
mtext("Water temperature [�C]", side = 4, cex = 0.9, line = 1.75)
axis(side = 4, at = pretty(range(Water_temperature_dt$V2[121:3024]), n = 20), las = 2, cex.axis = 0.8)
par(new = T)
plot(time_h, Weight_dt$W, type = "l", xlab = "", ylab = "", xaxt  ="n", yaxt = "n", ylim = c(min(vaki_MA$Weight_mean, na.rm = T), max(c(vaki_MA$Weight_mean, Weight_dt$W), na.rm = T)))
lines(vaki_MA$time[4:124], vaki_MA$Weight_mean[4:124], col = "red")
points(date_leonardi, pesi_leonardi, pch = 20, col = "darkgreen")

axis(side = 2, at = pretty(range(Weight_dt$W)), cex.axis = 0.9, las = 2)
mtext( "Weight [g]", side = 2, line = 3, cex = 0.9)
axis.POSIXct(side = 1, at = dates_lab, format = "%d %b",cex.axis = 0.9)
mtext("Time [h]", side = 1, line = 2.5, cex = 0.9)
legend(dates_lab[1], 200, legend = c("Model", "BD"), xpd = T, bty = "n", col = c("black", "red"), lty = c(1,1), cex = 0.9)
legend(dates_lab[3], 200, legend = "Samples", pch = 20, col = "darkgreen", xpd = T, bty = "n", cex = 0.9)
legend(dates_lab[7], 200, legend = "Water temperature", lty = 1, col = "grey", xpd = T, bty = "n", cex = 0.9)



vaki_MA_limitato = vaki_MA[4:124,]

vaki_MA_limitato$time = strptime(vaki_MA_limitato$time, format = "%d/%m/%Y", tz = "UTC")





date_prendere = vaki_MA_limitato$time[ is.na(vaki_MA_limitato$Weight_mean) == F]
pesi_predende = vaki_MA_limitato$Weight_mean[ is.na(vaki_MA_limitato$Weight_mean) == F]



pesi_confronto = rep(NA, length(date_prendere))


i = 1
for (i in 1:length(date_prendere) ) {
  
  pesi_confronto[i] = Weight_dt$W[format(Weight_dt$time, format = "%d/%m/%Y %H:") ==  format(date_prendere[i], format = "%d/%m/%Y %H:")]
  
}



sqrt(mean((pesi_predende - pesi_confronto)^2))
sum((pesi_predende - pesi_confronto)^2)

sd(pesi_predende - pesi_confronto)



summary(lm(pesi_predende~pesi_confronto))




Sys.setlocale("LC_TIME", "English")
par(mar = c(4,3,1,1))
plot(pesi_confronto, pesi_predende, xlim = c(250,600), ylim = c(250,600), pch = 20,
     xlab = "", ylab = "")
mtext(text = "Predicted weight [g]", side = 1, line = 2.25, cex = 0.9)
mtext(text = "Weight by BD [g]", side = 2, line = 2, cex = 0.9)
abline(a = 0, b = 1, lty = 2)
abline(a = 20.79346, b = 0.94937, col = "red")


cor(x = pesi_confronto, y = pesi_predende)

sum(feed_day)/(pesi_confronto[length(pesi_confronto)]-pesi_confronto[1])
sum(feed_day)/(pesi_predende[length(pesi_predende)]-pesi_predende[1])


library(plotrix)
par(mar = c(5,4,1,1))

taylor.diagram(pesi_predende, pesi_confronto, pos.cor= F, col = "blue", pch = 20,
               mar = c(5,1,5,1))



date_biomassa = seq(from = strptime("06/07/2020 00: ", format = "%d/%m/%Y %H:", tz = "UTC"),
                    to = strptime("03/11/2020 00:", format = "%d/%m/%Y %H:", tz = "UTC"),
                    by = "day")

pesi_biomassa = rep(NA, length(date_biomassa))


i = 1
for (i in 1:length(date_biomassa)) {
  
  pesi_biomassa[i] = Weight_dt$W[format(Weight_dt$time, format = "%d/%m/%Y %H:") == format(date_biomassa[i], format = "%d/%m/%Y %H:")]
  
}




biomassa_totale = pesi_biomassa * Leonardi_gestionale_lim$Num./(10^6)
  




Sys.setlocale("LC_TIME", "English")
par(mar = c(4,3,1,4))
plot(time_d, Leonardi_gestionale_lim$Num./1000, type = "l", col = "grey",
     xlab = "", xaxt = "n", ylab = "", yaxt = "n")
mtext(text = "Number of individuals [10^3]", side = 4, line = 2.5, cex = 0.9)
axis(side = 4, at = seq(from = 25, to =  45, by = 2.5), las = 2, cex.axis = 0.9)
par(new = T)
plot(time_d, biomassa_totale, type = "l", xlab = "", xaxt = "n", ylab = "", yaxt = "n")
axis.POSIXct(side = 1, at = dates_lab, format = "%d %b")
mtext(text = "Total Biomass [ton]", side = 2, line = 2, cex = 0.9)
axis(side = 2, at = pretty(range(biomassa_totale)), las = 2, cex.axis = 0.9)
mtext(text = "Time [d]", side = 1, line = 2.5, cex = 0.9)
legend(dates_lab[1], 7.85, cex = 0.9, xpd = T, bty = "n", legend = "Total Biomass", 
       lty = 1, col = "black")
legend(dates_lab[7], 7.85, cex = 0.9, xpd = T, bty = "n", legend = "Number of fish", 
       lty = 1, col = "grey")


