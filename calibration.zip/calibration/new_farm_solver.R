#' Script con la definizione dei parametri necessari per i due moduli.
#' Inoltre, sono presenti anche tutte le equazioni necessarie per i due bilanci:energetico ed ossigeno disciolto, 
#' ad eccezzione delle due equazioni differenziali che saranno in un'altra funzione con il solo sistema di ODEs
#' In aggiunta, vengono prodotto anche le funzioni interpolanti delle forzanti
#' 

farm_solver = function(forcings, Param_vct){
  
  print("Inside farm solver")
  # print(environment())
  
  # Estrazione dei tempi da forcings 
  index_time = forcings[[1]]
  # print(index_time)
  ti = index_time[2]
  # print(ti)
  tf = index_time[3]
  # print(tf)
  timestep = index_time[4]
  
  # Estrazione dei parametri
  
  Param = Param_vct
  print("Parametri solver")
  print(Param)
  
  
  # Estrazione della composizione del cibo
  Food = forcings[[3]]
  # print(Food)
  
  
  
  # libreria per routine
  library(deSolve)
  
  # Estrazione delle condizioni iniziali
  IC = forcings[[11]]
  cat("IC", IC, "\n")
  # Definition of simulation time
  
  sim_time = seq(from = ti, to = tf, by = timestep)              # equivalent to ti:tf
  
  # Definition of parameters vector
  parameters = c(Param[1:26], Food)
  print("parameters to ODE")
  print(parameters)
  
  # Line for solution
  out = ode(y = IC, times = ti:tf, func = Diff_equation_set, parms = parameters, method = "rk4")
  
  return(
    list(out 
         
         
    ))
  
}


