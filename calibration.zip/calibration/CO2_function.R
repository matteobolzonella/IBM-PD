CO2_function = function(pH_values_input, Temperature, parameter_CO2){
  # Temperature = Temperature_app(t)
  # pH = pH_app(t)
  
  pH = pH_values_input
  Temperature = Temperature
  
  # Conversion of temperature in Kelvin
  Temperature_K = Temperature + 273.15
  
  # Estimation of H+ quantity
  H = 10^(-pH)
  
  # Definition of molecular mass
  M_CO2 = 44.01              #[g/mol] molecular mass of CO2
  M_HCO3 = 61.0168           #[g/mol] molecular mass of HCO3-
  M_CO3 = 60.009             #[g/mol] molecular mass of CO3,2-
  
  alka = parameter_CO2[1]
  pCO2 = parameter_CO2[2]
  
  # # Estimation of equilibrium constant between  
  # pK0 = -2622.38/Temperature_K - 0.0178471*Temperature_K + 15.5873
  # K0 = 10^(-pK0)
  
  #Estimation of equilibrium constant between CO2 and HCO3-
  pK1 = 3404.71/Temperature_K + 0.032786*Temperature_K - 14.8435
  K1 <- 10^(-pK1)
    
  #Estimation of equilibrium constant between HCO3- and CO3,2-
  pK2 <- 2902.39/Temperature_K + 0.02379*Temperature_K - 6.4980
  K2 = 10^(-pK2)
  
  eq_1 = (alka*H^2)/((H*K1) + (2*K1*K2))
  eq_2 = (alka*H)/(H+(2*K2))
  eq_3 = (alka*K2)/(H+(2*K2))
  
  CO2 = eq_1 * M_CO2
  HCO3 = eq_2 * M_HCO3
  CO3 = eq_3 * M_CO3
  
  return( list(CO2, HCO3, CO3))
}




