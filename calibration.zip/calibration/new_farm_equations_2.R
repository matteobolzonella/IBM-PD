# Script con la definizione del sistema di equazioni differenziali


Diff_equation_set = function(t, IC, parameters){
  with(as.list(c(IC, parameters)),{
    
    # Lettura delle funzioni forzanti
    ingvero = ingvero_app(t)
    Temperature = Temperature_app(t)
    G = G_app(t)
    DO_input = DO_input_app(t)
    liq_oxygen = liq_O2_app(t)
    NUM = pop_num_app(t)
    NH4_input = NH4_input_app(t)
    
    # Definizione dei parametri
    alpha = parameters[2]         # [-] Feeding catabolism coefficient
    betaprot = parameters[3]      # [-] Assimilation coefficient for protein
    betalip = parameters[4]       # [-] Assimilation coefficient for lipid
    betacarb = parameters[5]      # [-] Assimilation coefficient for carbohydrates
    epsprot = parameters[6]       # [J/gprot] Energy content of protein
    epslip = parameters[7]        # [J/glip] Energy content of lipid
    epscarb = parameters[8]       # [J/gcarb] Energy content of carbohydrate
    epsO2 = parameters[9]         # [J/gO2] Energy consumed by the respiration of 1g of oxygen
    pk = parameters[10]           # [1/�C] Temperature coefficient for the fasting catabolism
    k0 = parameters[11]           # [1/h]  Fasting catabolism at 0 Celsius degree
    n = parameters[13]            # [-] Weight exponent for the catabolism
    betac = parameters[14]        # [-]  Shape coefficient for the H(Tw) function
    Tma = parameters[15]          # [Celsius degree] Maximum lethal temperature for Oncorhynchus mykiss
    Toa = parameters[16]          # [Celsius degree] Optimal temperature for Oncorhynchus mykiss
    Taa = parameters[17]          # [Celsius degree] Lowest feeding temperature for Oncorhynchus mykiss
    a = parameters[18]            # [J/gtissue] intercept for somatic energy of fish tissue
    eff = parameters[19]          # [-] Food ingestion efficiency
    q = parameters[20]            # [m3/h] Water flow
    V = parameters[21]            # [m3] Volume of raceway
    krear = parameters[22]        # [1/h] constant of rearation coefficient
    z = parameters[23]            # [mgO2/L] intercept of equation for estimation DO saturation
    k1_DOsat = parameters[24]     # [1/�C] coefficient for first power water temperature in DO saturation equation
    k2_DOsat = parameters[25]     # [1/(�C)^2] coefficient for second power water temperature in DO saturation equation
    k3_DOsat = parameters[26]     # [1/(�C)^3] coefficient for third power water temperature in DO saturation equation
   
    
    
    #� Definizione della composizione del cibo
    Pcont=parameters[27]                                             # [-] Percentage of proteins in the food
    Lcont=parameters[28]                                             # [-] Percentage of lipids in the food
    Ccont=parameters[29]                                             # [-] Percentage of carbohydrates in the food
    
    # Energy content of somatic tissue [J/g] Source:  Van Poorten (2010)
    epstiss=a
    
    # Forcing temperature on assimilation
    fgT = (((Tma-Temperature)/(Tma-Toa))^(betac*(Tma-Toa)))*exp(betac*(Temperature-Toa)) # Optimum Temperature dependance for ingestion
    # Temperature dependence for catabolism
    frT = exp(pk*Temperature)
    
    
    # Ingested energy
    diet = (Pcont*epsprot*betaprot+Lcont*epslip*betalip+Ccont*epscarb*betacarb) # *  fgT # [J/g] Energy content of the ingested food
    assE = ingvero * diet
    
    ### Equations for DO budget
    # DO in entrata
    entrata = (q*DO_input)/V
    
    # DO saturation
    DO_sat = z - (k1_DOsat*Temperature) + (k2_DOsat*((Temperature)^2)) - (k3_DOsat*((Temperature)^3))
    
    # Input Ammonio
    # NH4_in = (q*NH4_input)/V
    
    #
    # v = (V*10^3)
    
    dW = ((assE*(1-alpha)) - (epsO2*k0*frT*(W^n)))/epstiss
    dDO = -(q*DO)/V + entrata + liq_oxygen - ((k0*frT*(W^n)*NUM)/V) + (krear*(DO_sat - DO))
    # dNH4 = -(q*NH4)/V + NH4_in + ((r_exc*(NUM*(W^n)))/(v))
    
    # Comandi output
    
    anab = (assE*(1-alpha))
    catab = (epsO2*k0*frT*(W^n))
    
    # Compute excretion
    Pexc=(1-betaprot)*Pcont*ingvero     # Excreted proteins [g/h]
    Lexc=(1-betalip)*Lcont*ingvero      # Excreted lipids [g/h]
    Cexc=(1-betacarb)*Ccont*ingvero     # Excreted carbohydrates [g/h]
    
    # Compute waste
    Pwst=((G/eff)-ingvero)*Pcont     # Proteins to waste [g/h]
    Lwst=((G/eff)-ingvero)*Lcont     # Lipids to waste [g/h]
    Cwst=((G/eff)-ingvero)*Ccont     # Carbohydrates to waste [g/h]
    
    # Fish contribution to ammonia in water
    #Nfish = r_exc*(NUM*(W^n))/(v)
    
    list(
      c(dW, dDO),
      Anab = anab,
      Catab = catab,
      H_T = fgT,
      k_T = frT,
      excP = Pexc,
      excL = Lexc,
      excC = Cexc,
      wstP = Pwst,
      wstL = Lwst,
      wstC = Cwst,
      DO_entry = entrata,
      Liq_O2 = liq_oxygen,
      DO_saturation = DO_sat,
      Temp = Temperature,
      I = ingvero
      # NH4_inp = NH4_in,
      # fishN = Nfish 
      
    )
  })
}
