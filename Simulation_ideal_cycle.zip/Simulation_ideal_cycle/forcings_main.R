
userpath = "..."

Water_temperature_dt = read.csv(file = paste0(userpath,"/Water_temperature.csv"), sep = ",", header=F)                      # Reading the temperature time series (hourly series) data

# Reads feed composition file
Food_matrix = read.csv(file = paste0(userpath,"/Food_characterization.csv"), sep = ",", header = F)   # Reading the food composition (Proteins, Lipids, Carbohydrates) data
Food=as.double(as.matrix(Food_matrix[,1]))                                                            # Trasformazione dei valori della matrice della caratterizzazione del cibo in vettore di numeri reali

# Reads integration extremes
Param_matrix = read.csv(file = paste0(userpath,"/Parameters.csv"), sep=",", header = T)        # Reading the matrix containing parameters and their description
Param=as.double(as.matrix(Param_matrix[1:31,3]))                                               # conversione dei valori dei parametri della matrici in vettore di numeri reali


# qui definisco il vettore della temperatura senza passare per il file forzante

# Temperature =
Temperature = Water_temperature_dt$V2
# Temperature_df = data.frame(time = ti:tf, Temperature = Temperature[t1:tf])
# Temperature_app <<- approxfun(Temperature_df, rule = 2)
# ti = 8929
ti = 2185
# tf = 24
#tf = length(Water_temperature_dt$V2)
tf = 10944

Temperature_df = data.frame(time = ti:tf, Temperature = Temperature[ti:tf])
Temperature_app <<- approxfun(Temperature_df, rule = 2)

# Temperatura dell'acqua
# Temperature_df = data.frame(time = ti:tf, Temperature = Temperature)
# Temperature_app <<- approxfun(Temperature_df, rule = 2)

G = rep(1, length(Temperature))
G[4369:5472] = 0
# Razione alimentare fornita dall'allevatore
G.df = data.frame(time = ti:tf, G = G[ti:tf])
G_app <<- approxfun(G.df, rule = 2)

parameters = c(Param[1:26], Food)

# Initial conditions


n = 5000

# num_in = NUM_dt$num_stimata[1]
num_in = n
#num = NUM_dt$num_stimata[2:length(NUM_dt$num_stimata)]


set.seed(1)
# IC = (W = as.double(as.matrix(Param_matrix[34,3])))
IC = as.double(as.matrix(Param_matrix[34,3]))
IC_norm = rnorm(num_in-1, mean = as.double(as.matrix(Param_matrix[34,3])), sd = 5)

IC_norm[IC_norm<=0]
length(IC_norm[IC_norm<=0])

IC_norm[IC_norm<=0] = rnorm(length(IC_norm[IC_norm<=0]), mean = as.double(as.matrix(Param_matrix[34,3])), sd = 5)


IC = c(IC, IC_norm)


parameters = c(Param[1:26], Food)
alfa = c(parameters[2], rnorm(n = num_in-1, mean = 0.579, sd = 0.059))
#alfa[alfa<=0]


parameters_mtx = matrix(parameters, ncol = num_in, nrow = length(parameters), byrow = F)
parameters_mtx[2,] = alfa

k0 =  c(parameters[11], (rnorm(n = num_in-1, mean = (8.5*10^-4), sd = (4.3*10^-5)))/24)
parameters_mtx[11,] = k0


library(deSolve)


out = ode(y = IC, times = ti:tf, func = Diff_equation_set2, parms = parameters, alfa = alfa, k0 = k0, method = "rk4")



Pesi_mtx = out[,2:5001]
Anab_mtx = out[,5002:10001]
Catab_mtx = out[,10002:15001]
I_ideal_mtx = out[,15002:20001]
other_mtx = out[,20002:20004]

write.csv(x = Pesi_mtx, file = ".../weight_nomort.csv", row.names = F)
write.csv(x = Anab_mtx, file = ".../Anab_nomort.csv", row.names = F)
write.csv(x = Catab_mtx, file = ".../Catab_nomort.csv", row.names = F)
write.csv(x = I_ideal_mtx, file = ".../Iideal_nomort.csv", row.names = F)
write.csv(x = other_mtx, file = ".../Other.csv", row.names = F)
