
Diff_equation_set2 = function(t, W, parameters, alfa, k0){
  with(as.list(c(parameters, alfa, k0)),{
    
    Temperature = Temperature_app(t)
    G = G_app(t)
    
    # print(parameters)
    # print(prova)
    # print(IC)
    # Definizione dei parametri
    Imax = parameters[1]          # [J/((g_fish^m)*h)] Maximum ingestion rate
    alpha = alfa
    #alpha = parameters[2,t]         # [-] Feeding catabolism coefficient
    betaprot = parameters[3]      # [-] Assimilation coefficient for protein
    betalip = parameters[4]       # [-] Assimilation coefficient for lipid
    betacarb = parameters[5]      # [-] Assimilation coefficient for carbohydrates
    epsprot = parameters[6]       # [J/gprot] Energy content of protein
    epslip = parameters[7]        # [J/glip] Energy content of lipid
    epscarb = parameters[8]       # [J/gcarb] Energy content of carbohydrate
    epsO2 = parameters[9]         # [J/gO2] Energy consumed by the respiration of 1g of oxygen
    pk = parameters[10]           # [1/�C] Temperature coefficient for the fasting catabolism
    # k0 = parameters[11]           # [1/h]  Fasting catabolism at 0 Celsius degree
    k0 = k0
    m = parameters[12]            # [-] Weight exponent for the anabolism
    n = parameters[13]            # [-] Weight exponent for the catabolism
    betac = parameters[14]        # [-]  Shape coefficient for the H(Tw) function
    Tma = parameters[15]          # [Celsius degree] Maximum lethal temperature for Oncorhynchus mykiss
    Toa = parameters[16]          # [Celsius degree] Optimal temperature for Oncorhynchus mykiss
    Taa = parameters[17]          # [Celsius degree] Lowest feeding temperature for Oncorhynchus mykiss
    a = parameters[18]            # [J/gtissue] intercept for somatic energy of fish tissue
    eff = parameters[19]          # [-] Food ingestion efficiency
    # q = parameters[20]            # [m3/h] Water flow
    # V = parameters[21]            # [m3] Volume of raceway
    # krear = parameters[22]        # [1/h] constant of rearation coefficient
    # z = parameters[23]            # [mgO2/L] intercept of equation for estimation DO saturation
    # k1_DOsat = parameters[24]     # [1/�C] coefficient for first power water temperature in DO saturation equation
    # k2_DOsat = parameters[25]     # [1/(�C)^2] coefficient for second power water temperature in DO saturation equation
    # k3_DOsat = parameters[26]     # [1/(�C)^3] coefficient for third power water temperature in DO saturation equation
    
    
    
    # Definizione della composizione del cibo
    Pcont=parameters[27]                                             # [-] Percentage of proteins in the food
    Lcont=parameters[28]                                             # [-] Percentage of lipids in the food
    Ccont=parameters[29]                                             # [-] Percentage of carbohydrates in the food
    
    
    # Energy content of somatic tissue [J/g] Source:  Van Poorten (2010)
    epstiss=a
    
    
    
    
    # Forcing temperature on assimilation
    fgT = (((Tma-Temperature)/(Tma-Toa))^(betac*(Tma-Toa)))*exp(betac*(Temperature-Toa)) # Optimum Temperature dependance for ingestion
    # Temperature dependence for catabolism
    frT = exp(pk*Temperature)
    
    
    # Ingested energy
    diet = (Pcont*epsprot*betaprot+Lcont*epslip*betalip+Ccont*epscarb*betacarb) # *  fgT # [J/g] Energy content of the ingested food
    
    #print(W)
    # assE = G * diet
    if (Temperature > 2) {
      
    }else{
      G = 0
    }
    
    
    if(G != 0){
      
      dW = ((Imax * fgT * (W^m)*(1-alpha)) - (epsO2*k0*frT*(W^n)))/epstiss
      ing = Imax * fgT * (W^m)
      #ing_g = ing/diet
      
      
    }else{
      ing = G*diet
      #ing_g = ing/diet
      dW = ((ing*(1-alpha)) - (epsO2*k0*frT*(W^n)))/epstiss
      
    }
    
    #print(ing)
    
    # dW = ((assE*(1-alpha)) - (epsO2*k0*frT*(W^n)))/epstiss
    #dW  = ((Imax * fgT * (W^m)*(1-alpha)) - (epsO2*k0*frT*(W^n)))/epstiss
    # dDO = DO
    
    # Comandi output
    
    anab = (ing *(1-alpha))
    catab = (epsO2*k0*frT*(W^n))
    
    
    if(G != 0){
      #print(W)
      #ing = Imax * fgT * (IC^m)
      
      ing = Imax * fgT * (W^m)
    }else{
      ing = G*diet*W
      
    }
    # ing_vero = Imax * fgT * (W^m)
    
    list(
      c(dW)
      ,# dDO),
      Anab = anab,
      Catab = catab,
      I = ing/diet,
      H_T = fgT,
      k_T = frT,
      Temp = Temperature,
      Feed = G
      
    )
  })
}



