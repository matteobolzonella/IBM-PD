Iideal_dt = read.csv(file = ".../Iideal_nomort.csv",
                      sep = ",", header = T)
pesi_dt = read.csv(file = ".../weight_nomort.csv", 
                    sep = ",", header = T)
Catab_dt = read.csv(file = ".../Catab_nomort.csv", 
                   sep = ",", header = T)
k_dt = read.csv(file = ".../num_ind_mort_h.csv",
                 sep = ",", header = T)

Iideal_dt_backup = Iideal_dt
pesi_dt_backup = pesi_dt
Catab_dt_backup = Catab_dt

# head(pesi_dt_backup[,c(1,5000)])

time = seq(from = strptime("01/04/2020 00:", format = "%d/%m/%Y %H:", tz = "UTC"),
           to = strptime("31/03/2021 23:", format = "%d/%m/%Y %H:", tz = "UTC"),
           by = "hour")


time_2 = seq(from = strptime("01/04/2020 00:", format = "%d/%m/%Y %H:", tz = "UTC"),
           to = strptime("01/04/2021 00:", format = "%d/%m/%Y %H:", tz = "UTC"),
           by = "hour")


time_2[4369 - 2185 + 1]
time_2[5472 - 2185 + 1]

G = rep(1, length(time_2))
G[2185:3288] = 0
# Razione alimentare fornita dall'allevatore
G.df = data.frame(time = 1:length(time_2), G = G[1:length(time_2)])
G_app <<- approxfun(G.df, rule = 2)



plot(time, G.df$G, type = "l")
lines(time, G_app(2185:10944), col = "red")




ODE_numerosit� = function(t, NUM, par){
  with(as.list(c(par)),{
    
    G = G_app(t)
    
    m = par[1]
    mv = par[2]
    #cat("m", m, "\n")
    
    if (G == 0) {
      
      dNUM = (-m*NUM) - mv*NUM
      
    }
    else{
      
      dNUM = -m*NUM
    }
    
    
    list(dNUM)
  })
}

library(deSolve)
NUM_ini = 5000
par = c((0.002715437/24), (0.001880942/24))
# divido per 24 perhc� il tasso di mortalit� � su base giornaliera

times = 2185:(10944+1)


nume_temp = rep(NA, length(times))

nume_temp[1] = NUM_ini


out_num2 = ode(y = NUM_ini, times = times, func = ODE_numerosit�, parms = par, method = "rk4")
# 
# plot(nume_temp, type = "l", ylim = c(0,5000))
# lines(round(out_num2[,2], digits = 0), col = "red")


time_h = seq(from = strptime("01/04/2020 00:", format = "%d/%m/%Y %H:", tz = "UTC"),
             to = strptime("01/04/2021 00:", format = "%d/%m/%Y %H:", tz = "UTC"),
             by = "hour")

dates_lab = seq(from = strptime("01/04/2020 00:", format = "%d/%m/%Y %H:", tz = "UTC"),
                to = strptime("01/04/2021 00:", format = "%d/%m/%Y %H:", tz = "UTC"),
                by = (60*60*24*31))

length(time_h)
length(out_num2[,2])

Sys.setlocale("LC_TIME", "English")
par(mar = c(4,3,1,1))
plot(time_h, round(out_num2[,2], digits = 0), type = "l", xaxt = "n", xlab = "", ylab = "Number of individuals", main = "",
     yaxt = "n")
axis.POSIXct(side = 1, at = dates_lab, format = "%d %b %y", cex.axis = 0.7)
mtext(text = "Time [h]", side = 1, line = 2.5, cex = 0.9)
mtext(text = "Number of individuals", side = 2, line = 2, cex = 0.9)
axis(side = 2, at = pretty(range(round(out_num2[,2], digits = 0))), cex.axis = 0.9)
legend(dates_lab[1], 1125, legend = "Number of individuals", xpd = T, bty = "n",
       cex = 0.9, lty = 1, col = "black")



k = -diff(round(out_num2[,2], digits = 0))
length(k)

write.csv(k, file = "C://Users/matbo/Desktop/pop_model_ideal_cycle/simulazione_anno_intero/risultati_simort/num_ind_mort_h.csv", row.names = T)

k = k_dt$x


n = 1:5000
A= rep (NA,length (n))
# k=c(0,4,6,10,5, rep(1,2899))
for (i in 2:8760){
  pos_morti = sample (n,k[i],replace=F)
  cat("i vale:",i,"\n")
  cat ("pos_morti",pos_morti, " \n")
  cat ("k_dt$k[i] ",k[i],"\n")
  if (length(pos_morti)>0)
  {
    for (j in 1:length (pos_morti))
    {
      Z=pos_morti[j]
      while (is.na(A[Z])== F)
      {
        AUX=sample (n,1,replace=F)
        Z=AUX
      }
      A[Z]=i
    }
  }
}


for (i in 1:length(A)){
  Z=A[i]
  #cat ("Z=",Z,"\n")
  if (is.na(Z)== F)
  {
    
    Iideal_dt_backup[Z:8760,i]=NA
    pesi_dt_backup[Z:8760,i]=NA
    Catab_dt_backup[Z:8760,i]=NA
    
  }
}
# cat("matricione\n")
# Iideal_dt_backup





write.csv(x = Iideal_dt_backup, file = ".../Iideal_pop_simort.csv",
          row.names = F)

write.csv(x = pesi_dt_backup, file = ".../pesi_pop_simort.csv",
          row.names = F)

write.csv(x = Catab_dt_backup, file = ".../Catab_pop_simort.csv",
          row.names = F)
