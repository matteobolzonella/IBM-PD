Iideal_dt = read.csv(file = ".../Iideal_pop_simort.csv",
                     sep = ",", header = T)
pesi_dt = read.csv(file = ".../pesi_pop_simort.csv", 
                   sep = ",", header = T)

k_dt = read.csv(file = ".../num_ind_mort_h.csv",
                sep = ",", header = T)

Iideal_dt_backup = Iideal_dt
pesi_dt_backup = pesi_dt
# Catab_dt_backup = Catab_mtx



peso_medio_h = rep(NA, length(pesi_dt_backup[,1]))
peso_sd_h = rep(NA, length(pesi_dt_backup[,1]))


time = seq(from = strptime("01/04/2020 00:", format = "%d/%m/%Y %H:", tz = "UTC"),
           to = strptime("31/03/2021 23:", format = "%d/%m/%Y %H:", tz = "UTC"),
           by = "hour")




peso_medio_h = apply(X = pesi_dt_backup, MARGIN = 1, FUN = mean, na.rm = T)
peso_sd_h = apply(X = pesi_dt_backup, MARGIN = 1, FUN = sd, na.rm = T)

peso_medio_sd_h = data.frame(time = format(time, format = "%d/%m/%Y %H:"), 
                             peso_medio = peso_medio_h,
                             sd_peso = peso_sd_h)


write.csv(x = peso_medio_sd_h, file = ".../peso_medio_sd.csv", row.names = F)

peso_medio_sd_h_dt = read.csv(file = ".../peso_medio_sd.csv",
                              sep = ",", header = T)

peso_medio_sd_h_dt$time = strptime(peso_medio_sd_h_dt$time, format = "%d/%m/%Y %H:", tz = "UTC")
peso_medio_h = peso_medio_sd_h_dt$peso_medio
peso_sd_h = peso_medio_sd_h_dt$sd_peso


peso_medio_sd_h_dt$time[peso_medio_sd_h_dt$peso_medio > 1500]

length(seq(from = strptime("01/04/2020 00:", format = "%d/%m/%Y %H:", tz = "UTC"),
    to = strptime("11/03/2021 00:", format = "%d/%m/%Y %H:", tz = "UTC"),
    by = "day"))


time = seq(from = strptime("01/04/2020 00:", format = "%d/%m/%Y %H:", tz = "UTC"),
           to = strptime("31/03/2021 23:", format = "%d/%m/%Y %H:", tz = "UTC"),
           by = "hour")


# time_2 = seq(from = strptime("01/04/2020 00:", format = "%d/%m/%Y %H:", tz = "UTC"),
#              to = strptime("22/01/2021 12:", format = "%d/%m/%Y %H:", tz = "UTC"),
#              by = "hour")

time[6576]

dates_lab = seq(from = strptime("01/04/2020", format = "%d/%m/%Y", tz = "UTC"), 
                to = strptime("01/04/2021", format = "%d/%m/%Y", tz = "UTC"), by = "month")


Sys.setlocale("LC_TIME", "English")
par(mar = c(4,4,1,3))
plot(time, Temperature_df$Temperature, type = "l", xlab = "", xaxt = "n", axes = F, ylab = "", col = "grey")
axis(4,at =  pretty(range(Temperature_df$Temperature), n = 10), las = 1, cex.axis = 0.9)
mtext("Water temperature [�C]", side = 4, line = 1.75, cex = 0.9)
box()
par(new = T)
plot(time, peso_medio_h, type = "l", main = "", ylab = "", xaxt = "n", yaxt = "n", 
     ylim = c(min(peso_medio_h - peso_sd_h),max(peso_medio_h + peso_sd_h)), xlab = "")
lines(time, peso_medio_h- peso_sd_h, lty = 2)
lines(time, peso_medio_h + peso_sd_h, lty = 2)
axis.POSIXct(side = 1, at = dates_lab, format = "%d %b", cex.axis = 0.75)
axis(side = 2, at = pretty(range(peso_medio_h + peso_sd_h), n = 10), cex.axis = 0.75, las = 2)
mtext(text = "Weight [g]", side = 2, line = 3, cex = 0.9)
mtext(text = "Time [h]", side = 1, line = 2.5, cex = 0.9)
legend(dates_lab[1], -350, xpd = T, bty = "n", legend = c("mean weight", "sd(weight)"), col = c("black", "black"),
       lty = c(1,2), cex = 0.8)
legend(dates_lab[9], -350, xpd = T, bty = "n", legend = "Water temperature", col = "grey", lty = 1, cex = 0.8)


#time_h[4824]

length(seq(from = strptime("01/04/2020", format = "%d/%m/%Y ", tz = "UTC"),
           to = strptime("28/12/2020", format = "%d/%m/%Y", tz = "UTC"),
           by = "day"))


eps_prot = 23600            # [J/g_prot]
eps_carb = 17200            # [J/g_carb]
eps_lipi = 36200            # [J/g_lip]


Pcont_6 = 0.442
Lcont_6 = 0.26
Ccont_6 = 0.158

betaprot =  0.93     # [-] Assimilation coefficient for protein
betalip = 0.94       # [-] Assimilation coefficient for lipid
betacarb =  0.67     # [-] Assimilation coefficient for carbohydrates

energy_6 = (eps_prot*Pcont_6*betaprot)+(eps_carb*Ccont_6*betacarb)+(eps_lipi*Lcont_6*betalip)




energy_h = apply(X = Iideal_dt_backup, MARGIN = 1, FUN = sum, na.rm = T)


Icumulato_h = data.frame(time = format(time, format = "%d/%m/%Y %H:"),
                         Energy_popcum_h = energy_h)


Icumulato_h$time = strptime(Icumulato_h$time, format = "%d/%m/%Y %H:", tz = "UTC")

Icumulato_h$I_popcum_h_kg = Icumulato_h$Energy_popcum_h/1000




i = 1

time_d = seq(from = strptime("01/04/2020 00:", format = "%d/%m/%Y %H:", tz = "UTC"),
             to = strptime("31/03/2021 00:", format = "%d/%m/%Y %H:", tz = "UTC"),
             by = "day")

Raz_tot_d = rep(NA, length(time_d))

for (i in 1:length(time_d)) {
  Raz_tot_d[i] = sum(Icumulato_h$I_popcum_h_kg[format(Icumulato_h$time, format = "%d/%m/%Y") == format(time_d[i], format = "%d/%m/%Y")])
  
  
}




Sys.setlocale("LC_TIME", "English")
par(mar = c(4,4,1,3))
plot(time_d, Raz_tot_d, col = "grey", xlab = "", ylab = "", xaxt = "n", yaxt = "n", type = "l")
axis(side = 4, at = pretty(range(Raz_tot_d), n = 10), cex.axis = 0.9)
mtext(text = "Feed ration [kg]", side = 4, line = 1.75, cex = 0.9)
par(new = T)
plot(time, peso_medio_h, type = "l", main = "", ylab = "", xaxt = "n", yaxt = "n", 
     ylim = c(min(peso_medio_h - peso_sd_h),max(peso_medio_h + peso_sd_h)), xlab = "")
lines(time, peso_medio_h- peso_sd_h, lty = 2)
lines(time, peso_medio_h + peso_sd_h, lty = 2)
axis.POSIXct(side = 1, at = dates_lab, format = "%d %b", cex.axis = 0.75)
axis(side = 2, at = pretty(range(peso_medio_h + peso_sd_h), n = 10), cex.axis = 0.75, las = 2)
mtext(text = "Weight [g]", side = 2, line = 3, cex = 0.9)
mtext(text = "Time [h]", side = 1, line = 2.5, cex = 0.9)
legend(dates_lab[1], -350, xpd = T, bty = "n", legend = c("mean weight", "sd(weight)"), col = c("black", "black"),
       lty = c(1,2), cex = 0.8)
legend(dates_lab[9], -350, xpd = T, bty = "n", legend = "Feed rations", col = "grey", lty = 1, cex = 0.8)






# plot(time_d, Raz_tot_d, type = "l")

HT_dt = read.csv(file = ".../Other.csv", sep = ",", 
                 header = T)


Energy_vero_ind = 76.29* HT_dt$H_T *((peso_medio_h)^0.67)


n = 5000
num_stimata = n - c(0,cumsum(k_dt$x[1:8759]))
length(num_stimata)



ing_vero_h_indmodel_kg = ((Energy_vero_ind/energy_6)*num_stimata)/1000

ing_vero_h_indmodel_kg_dt = data.frame(time = format(time, format = "%d/%m/%Y %H:"),
                                       ing_vero_h_indmodel_kg = ing_vero_h_indmodel_kg) 

ing_vero_h_indmodel_kg_dt$ing_vero_h_indmodel_kg[2185:3288] = 0
ing_vero_h_indmodel_kg_dt$time = strptime(ing_vero_h_indmodel_kg_dt$time, format = "%d/%m/%Y %H:", tz = "UTC")

prova = ing_vero_h_indmodel_kg_dt


ing_vero_h_indmodel_kg_dt$ing_vero_h_indmodel_kg[Temperature_df$Temperature <= 2] = 0









ing_vero_h_indmodel_kg_d = rep(NA, length(time_d))

i = 1
for (i in 1:length(time_d)) {
  
  ing_vero_h_indmodel_kg_d[i] = sum(ing_vero_h_indmodel_kg_dt$ing_vero_h_indmodel_kg[format(ing_vero_h_indmodel_kg_dt$time, format = "%d/%m/%Y")== format(time_d[i], format = "%d/%m/%Y")])
  
}

time_d[276]

Sys.setlocale("LC_TIME", "English")
par(mar = c(4,4,1,3.5))
plot(time, Temperature_df$Temperature, type = "l", xlab = "", xaxt = "n", axes = F, ylab = "", col = "grey")
axis(4,at = pretty(range(Temperature_df$Temperature), n = 10), las = 1, line = 0, cex.axis = 0.9)
mtext("Water temperature [�C]", side = 4, line = 2, cex = 0.9)
box()
par(new = T)
plot(time_d, Raz_tot_d, type = "l", main = "", ylab = "", xlab = "",
     xaxt = "n", ylim = c(min(c(Raz_tot_d,ing_vero_h_indmodel_kg_d)), max(c(Raz_tot_d,ing_vero_h_indmodel_kg_d))),
     yaxt = "n")
lines(time_d, ing_vero_h_indmodel_kg_d, col = "red")
axis(side = 2, at = pretty(range(Raz_tot_d), n = 10), cex.axis = 0.8)
axis.POSIXct(side = 1, at = dates_lab, format ="%d %b", cex.axis = 0.75)
mtext(text = "Feed ration [kg]", side = 2, line = 2.5, cex = 0.9)
legend(dates_lab[1], -3.25, xpd = T, bty = "n", legend = c("population-based model"),
       lty = c(1), col = c("black"), cex = 0.9)
legend(dates_lab[9], -3.25, xpd = T, bty = "n", legend = c( "mean individual-based model"),
       lty = c(1), col = c("red"), cex = 0.9)
mtext(text = "Time [d]", side = 1, line = 2.5, cex = 0.9)


Sys.setlocale("LC_TIME", "English")
par(mar = c(4,3,1,1))
plot(time_d, ((ing_vero_h_indmodel_kg_d - Raz_tot_d)/ing_vero_h_indmodel_kg_d)*100, type = "l",
     main = "", xlab = "", ylab = "", xaxt = "n", yaxt = "n")
axis.POSIXct(side = 1, at = dates_lab, format ="%d %b", cex.axis = 0.75)
mtext(text = " Daily percentage of savings", side = 2, line = 2, cex = 0.9)
axis(side = 2, at = pretty(range(((ing_vero_h_indmodel_kg_d - Raz_tot_d)/ing_vero_h_indmodel_kg_d)*100, na.rm = T)), 
     cex.axis = 0.9)
mtext(text = "Time [d]", side = 1, cex = 0.9, line = 2.5)

Sys.setlocale("LC_TIME", "English")
par(mar = c(4,4,1,3.5))
plot(time, peso_medio_h, type = "l", main = "", ylab = "", xaxt = "n", yaxt = "n", 
     ylim = c(min(peso_medio_h - peso_sd_h),max(peso_medio_h + peso_sd_h)), xlab = "", col = "grey")
lines(time, peso_medio_h- peso_sd_h, lty = 2, col = "grey")
lines(time, peso_medio_h + peso_sd_h, lty = 2, col = "grey")
axis(side = 4, at = pretty(range(peso_medio_h + peso_sd_h), n = 10), cex.axis = 0.75, las = 2)
mtext(text = "Weight [g]", side = 4, line = 2.35, cex = 0.9)
par(new = T)
plot(time_d, ((ing_vero_h_indmodel_kg_d - Raz_tot_d)/ing_vero_h_indmodel_kg_d)*100, type = "l",
     main = "", xlab = "", ylab = "", xaxt = "n", yaxt = "n")
axis.POSIXct(side = 1, at = dates_lab, format ="%d %b", cex.axis = 0.75)
mtext(text = " Daily percentage of savings", side = 2, line = 2.5, cex = 0.9)
axis(side = 2, at = pretty(range(((ing_vero_h_indmodel_kg_d - Raz_tot_d)/ing_vero_h_indmodel_kg_d)*100, na.rm = T), n = 10), 
     cex.axis = 0.9)
mtext(text = "Time [d]", side = 1, cex = 0.9, line = 2.5)
legend(dates_lab[1], 0.45, legend = c("Mean weight", "SD weight"), lty = c(1,2), col = c("grey", "grey"), xpd = T, bty = "n",
       cex = 0.9)
legend(dates_lab[9], 0.425, legend = c("Percentage of saving"), lty = c(1), col = c("black"), xpd = T, bty = "n",
       cex = 0.9)


plot(time_d[1:275], ((Raz_tot_d[1:275] - ing_vero_h_indmodel_kg_d[1:275] )/Raz_tot_d[1:275])*100, type = "l",
     main = "Daily precentage of feed savings", xlab = "Time [d]", ylab = "Daily percentage of feed saving", xaxt = "n")
axis.POSIXct(side = 1, at = dates_lab, format ="%d %b %y")

min(((Raz_tot_d - ing_vero_h_indmodel_kg_d)/Raz_tot_d)*100, na.rm = T)
max(((Raz_tot_d- ing_vero_h_indmodel_kg_d )/Raz_tot_d)*100, na.rm = T)
mean(((Raz_tot_d - ing_vero_h_indmodel_kg_d)/Raz_tot_d)*100, na.rm = T)

sum(Raz_tot_d)
sum(ing_vero_h_indmodel_kg_d)

sum(Raz_tot_d) - sum(ing_vero_h_indmodel_kg_d)


Raz_tot_d_dt = data.frame(time = format(time_d, format = "%d/%m/%Y"), 
                          Raz_pop_d = Raz_tot_d,
                          Raz_meanind_d = ing_vero_h_indmodel_kg_d)


Raz_tot_d_dt = read.csv()

write.csv(x = Raz_tot_d_dt, file = ".../Razioni_daily_ottimali_popmodel_meanind.csv",
          row.names = F)

write.csv(x = ing_vero_h_indmodel_kg_dt, file = ".../Raz_h_ideal_meanind.csv",
          row.names = F)





Sys.setlocale("LC_TIME", "English")
par(mar = c(5,4,4,5)+0.5)
plot(time[1:6576], Temperature_df[1:6576,2], type = "l", xlab = "", xaxt = "n", axes = F, ylab = "", col = "grey")
axis(4,ylim = c(pretty(range(Temperature_df[1:6576,2]))), las = 1, line = 0)
mtext("Water temperature [�C]", side = 4, line = 3)
box()
par(new = T)
plot(time_d[1:275], Raz_tot_d[1:275], type = "l", main = "Feed rations popolation-based vs mean individual-based", ylab = "Feed ration [kg]", xlab = "Time [d]",
     xaxt = "n", ylim = c(min(c(Raz_tot_d[1:275],ing_vero_h_indmodel_kg_d[1:275])), max(c(Raz_tot_d[1:275],ing_vero_h_indmodel_kg_d[1:275]))))
lines(time_d[1:275], ing_vero_h_indmodel_kg_d[1:275], col = "red")
axis.POSIXct(side = 1, at = dates_lab, format ="%d %b %y")
legend(time_d[1], -3, xpd = T, bty = "n", legend = c("population-based model", "mean individual-based model"),
       lty = c(1,1), col = c("black", "red"))
legend(dates_lab[12], -3, xpd = T, bty = "n", legend = "Water temperature", col = "grey", lty = 1)
# time_h[4824]





t.test(Raz_tot_d- ing_vero_h_indmodel_kg_d, conf.level = 0.95)



sum(Raz_tot_d[1:275])- sum(ing_vero_h_indmodel_kg_d[1:275])
sum(ing_vero_h_indmodel_kg_d[1:275])


((sum(Raz_tot_d[1:275])- sum(ing_vero_h_indmodel_kg_d[1:275]))/sum(ing_vero_h_indmodel_kg_d[1:275]))*100






biomassa = apply(pesi_dt_backup, MARGIN = 1, FUN = sum, na.rm = T)
biomassa_kg = biomassa / 1000

Sys.setlocale("LC_TIME", "English")
par(mar = c(4,3,1,4))
plot(time, num_stimata, type = "l", col ="grey", xaxt = "n", yaxt = "n", xlab = "", ylab = "")
axis(side = 4, at = pretty(range(num_stimata), n = 10), cex.axis = 0.9)
mtext(text = "Number of individuals", side = 4, line = 2.5, cex = 0.9)
par(new = T)
plot(time, biomassa_kg, type = "l",  xaxt = "n", yaxt = "n", xlab = "", ylab = "")
axis(side = 2, at = pretty(range(biomassa_kg), n = 10), cex.axis = 0.9)
mtext(text = "Total biomass [kg]", side = 2, line = 2, cex = 0.9)
axis.POSIXct(side = 1, at = dates_lab, format = "%d %b", cex.axis = 0.75)
mtext(text = "Time [h]", side = 1, line = 2.75, cex = 0.9)
legend(dates_lab[1], -350, legend = "Total biomass [kg]", cex = 0.9, col = "black", lty = 1,
       xpd = T, bty = "n")
legend(dates_lab[9], -350, legend = "Number of individuals", cex = 0.9, col = "grey", lty = 1,
       xpd = T, bty = "n")



biomassa

biomassa_dt = data.frame(time = format(time, format = "%d/%m/%Y %H:"), 
                         biomassa = biomassa)

Raz_tot_d_dt = data.frame(time = format(time_d, format = "%d/%m/%Y"), 
                         Raz_pop_d = Raz_tot_d)


(sum(Raz_tot_d[1:345])*1000)/(biomassa_dt$biomassa[8256] - biomassa_dt$biomassa[1])



(sum(Raz_tot_d[317:345])*1000)/(biomassa_dt$biomassa[8256] - biomassa_dt$biomassa[7584])

biomassa_dt$time[4632]
Raz_tot_d_dt$time[159:193]
